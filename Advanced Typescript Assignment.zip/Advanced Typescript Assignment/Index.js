"use strict";
//Question 1:
var a = "Aaniq";
console.log("Hello", a, "Would You like to Learn -----");
//Question 2:
var a = "aaniQ Farooq";
var au = a.toUpperCase();
var al = a.toLowerCase();
console.log(al);
//Question 3
var quote = 'Quaid-e-Azam once said, "Work, work, and work"';
console.log(quote);
//Question 4
var Quaid_e_Azam = "Work, work, and work";
var message = Quaid_e_Azam;
console.log(message);
//Question 5
const nameWithWhitespace = "\t   John Doe \n"; // Name with whitespace
console.log("Name with whitespace:");
console.log(nameWithWhitespace);
const strippedName = nameWithWhitespace.trim();
console.log("Name after stripping whitespace:");
console.log(strippedName);
//Question 6
var sum = 5 + 3;
var mul = 2 * 4;
var div = 16 / 2;
var sub = 16 - 8;
console.log(sum);
console.log(mul);
console.log(div);
console.log(sub);
//Question 7:
console.log(5 + 3);
console.log(2 * 4);
console.log(10 - 2);
console.log(16 / 2);
//Question 8
const favoriteNumber = 7;
const msg = `My favorite number is ${favoriteNumber}.`;
console.log(msg);
//Question 9
/*Quesion 8 Print A message Which Displays My Fav Number*/
//Question 10
var names = ["Aaniq", "Ali", "Hamza"];
// Print each person's name one at a time
for (var i = 0; i < names.length; i++) {
    console.log(names[i]);
}
//7/09/2023 
//Question 11
for (var i = 0; i < names.length; i++) {
    console.log(names[i], "is my friend");
}
//Question 12
var vehicle = ["Honda", "Audi", "BMW"];
for (var i = 0; i < vehicle.length; i++) {
    console.log("What Color is your", vehicle[i]);
}
//Question13
var guest = ["Eren", "Naruto", "Luffy"];
console.log(guest[0], "No Tatakae");
console.log(guest[1], "No Datebayo");
console.log(guest[2], "You are not king of Pirates");
//Question 14
guest[0] = "Sasuke";
console.log(guest[0], "Stfu Eren Is not coming");
//Question 15 16 To be continue later
//question17
var places = ["Maldives", "Makkah", "London", "Niagra", "Bali"];
console.log("String Orignal Order", places);
console.log("sorted Order", [...places].sort());
console.log("String Orignal Order", places);
console.log("Reverse Order", [...places].sort().reverse());
console.log("String Orignal Order", places);
places.reverse();
console.log("reverse ", places);
places.reverse();
console.log("again Reverse", places);
console.log("Orignal Order");
console.log(places);
places.sort();
console.log(places);
places.reverse();
console.log(places);
//Question 18
var guest = ["Eren", "Naruto", "Luffy"];
console.log("No of guests Are", guest.length);
//Question19
// Create an array of famous cities
const famousCities = [
    "New York City, USA",
    "Paris, Pakistan",
    "Tokyo, Japan",
];
// Print the list of famous cities
console.log("List of Famous Cities:");
for (var i = 0; i < 1; i++) {
    console.log(famousCities);
}
console.log("List of Famous Cities:");
for (const city of famousCities) {
    console.log(city);
}
var cities = {
    name: "faisalabad",
    famous: "textile"
};
console.log(cities.name);
//Question21
const numbers = [1, 2, 3, 4, 5];
// Intentional index error - accessing an element at an out-of-bounds index
const element = numbers[10];
// This line will cause an error so i am commenting it
//console.log(element); 
//question22
let age = 25;
// Test 1: Is the age less than 18?
console.log("Test 1: Is age < 18? I predict False.");
console.log(age < 18); // This will print False
// Test 2: Is the age greater than or equal to 18?
console.log("\nTest 2: Is age >= 18? I predict True.");
console.log(age >= 18); // This will print True
// Test 3: Is the age equal to 25?
console.log("\nTest 3: Is age == 25? I predict True.");
console.log(age == 25); // This will print True
// Test 4: Is the age not equal to 30?
console.log("\nTest 4: Is age != 30? I predict True.");
console.log(age != 30); // This will print True
// Test 5: Is the age between 20 and 30 (inclusive)?
console.log("\nTest 5: Is 20 <= age <= 30? I predict True.");
console.log(age >= 20 && age <= 30); // This will print True
// Test 6: Is the age divisible by 5?
console.log("\nTest 6: Is age divisible by 5? I predict True.");
console.log(age % 5 === 0); // This will print True
// Test 7: Is the age a negative number?
console.log("\nTest 7: Is age < 0? I predict False.");
console.log(age < 0); // This will print False
// Test 8: Is the age an even number?
console.log("\nTest 8: Is age even? I predict False.");
console.log(age % 2 === 0);
//Question23
// Tests for equality and inequality with strings
var fruit1 = "apple";
var fruit2 = "banana";
console.log("Equality Test 1: Are the fruits equal? I predict False.");
console.log(fruit1 === fruit2); // This will print False
console.log("\nInequality Test 1: Are the fruits not equal? I predict True.");
console.log(fruit1 !== fruit2); // This will print True
// Tests using the lowercase function
const text1 = "Hello, World!";
const text2 = "hello, world!";
console.log("\nLowercase Test 1: Are the texts lowercase equal? I predict True.");
console.log(text1.toLowerCase() === text2.toLowerCase()); // This will print True
// Numerical tests
var number1 = 42;
var number2 = 30;
console.log("\nEquality Test 2: Are the numbers equal? I predict False.");
console.log(number1 === number2); // This will print False
console.log("\nInequality Test 2: Are the numbers not equal? I predict True.");
console.log(number1 !== number2); // This will print True
console.log("\nGreater Than Test: Is number1 > number2? I predict True.");
console.log(number1 > number2); // This will print True
console.log("\nLess Than Test: Is number1 < number2? I predict False.");
console.log(number1 < number2); // This will print False
console.log("\nGreater Than or Equal To Test: Is number1 >= number2? I predict True.");
console.log(number1 >= number2); // This will print True
console.log("\nLess Than or Equal To Test: Is number1 <= number2? I predict False.");
console.log(number1 <= number2); // This will print False
// Tests using "and" and "or" operators
const isSunny = true;
const isWeekend = false;
console.log("\nAnd Operator Test: Is it sunny AND a weekend? I predict False.");
console.log(isSunny && isWeekend); // This will print False
console.log("\nOr Operator Test: Is it sunny OR a weekend? I predict True.");
console.log(isSunny || isWeekend); // This will print True
// Test whether an item is in an array
const fruitsArray = ["apple", "banana", "cherry", "date"];
console.log("\nArray Inclusion Test: Is 'cherry' in the fruits array? I predict True.");
console.log(fruitsArray.includes("cherry")); // This will print True
// Test whether an item is not in an array
console.log("\nArray Exclusion Test: Is 'grape' not in the fruits array? I predict True.");
console.log(!fruitsArray.includes("grape")); // This will print True
//Question 24
// Equality test with strings (True)
const string1 = "hello";
const string2 = "hello";
const result1 = string1 === string2;
// Inequality test with strings (False)
const string3 = "hello";
const string4 = "world";
const result2 = string3 !== string4;
// Numerical equality test (True)
const num1 = 10;
const num2 = 10;
const result4 = num1 === num2;
// Numerical inequality test (False)
const num3 = 5;
const num4 = 10;
const result5 = num3 !== num4;
// Greater than test (True)
const num5 = 15;
const num6 = 10;
const result6 = num5 > num6;
// Less than test (True)
const num7 = 5;
const num8 = 10;
const result7 = num7 < num8;
// Greater than or equal to test (True)
const num9 = 10;
const num10 = 10;
const result8 = num9 >= num10;
// Less than or equal to test (True)
const num11 = 5;
const num12 = 10;
const result9 = num11 <= num12;
// "And" operator test (True)
const condition1 = true;
const condition2 = true;
const result10 = condition1 && condition2;
// "Or" operator test (True)
const condition3 = true;
const condition4 = false;
const result11 = condition3 || condition4;
// Item in array test (True)
const array = [1, 2, 3, 4, 5];
const itemToFind = 3;
const result12 = array.includes(itemToFind);
// Item not in array test (False)
const array2 = [1, 2, 3, 4, 5];
const itemToFind2 = 6;
const result13 = !array2.includes(itemToFind2);
