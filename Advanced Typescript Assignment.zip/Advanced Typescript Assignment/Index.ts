
//Question 1:
var a:string="Aaniq"
console.log("Hello",a,"Would You like to Learn -----");
//Question 2:
 var a:string="aaniQ Farooq"
 var au = a.toUpperCase()
 var al = a.toLowerCase()
 console.log(al);
 //Question 3
 var quote = 'Quaid-e-Azam once said, "Work, work, and work"';
console.log(quote);
//Question 4
var Quaid_e_Azam:string =  "Work, work, and work";
var message:string=Quaid_e_Azam;
console.log(message);
//Question 5
const nameWithWhitespace = "\t   John Doe \n"; // Name with whitespace
console.log("Name with whitespace:");
console.log(nameWithWhitespace);
const strippedName = nameWithWhitespace.trim();
console.log("Name after stripping whitespace:");
console.log(strippedName);
//Question 6
var sum :number=5+3;
var mul :number=2*4;
var div :number=16/2;
var sub :number=16-8;
console.log(sum);
console.log(mul);
console.log(div);
console.log(sub);
//Question 7:
console.log(5+3);
console.log(2*4);
console.log(10-2);
console.log(16/2);
//Question 8
const favoriteNumber: number = 7; 
const msg = `My favorite number is ${favoriteNumber}.`;
console.log(msg);
//Question 9
/*Quesion 8 Print A message Which Displays My Fav Number*/
//Question 10
var names: string[] = ["Aaniq", "Ali", "Hamza"];

// Print each person's name one at a time
for (var i=0;i<names.length;i++) {
  console.log(names[i]);
}
//7/09/2023 
//Question 11
for (var i=0;i<names.length;i++){
  console.log(names[i],"is my friend");
}
//Question 12
var vehicle: string[] = ["Honda", "Audi", "BMW"];
for (var i=0;i<vehicle.length;i++){
  console.log("What Color is your",vehicle[i]);
}
//Question13
var guest:string[]=["Eren","Naruto","Luffy"];
console.log(guest[0],"No Tatakae");
console.log(guest[1],"No Datebayo");
console.log(guest[2],"You are not king of Pirates");
//Question 14
guest[0]="Sasuke"
console.log(guest[0],"Stfu Eren Is not coming");
//Question 15 16 To be continue later
//question17
var places:string[]=["Maldives","Makkah","London","Niagra","Bali"]
console.log("String Orignal Order",places);

console.log("sorted Order",[...places].sort());
console.log("String Orignal Order",places);
console.log("Reverse Order",[...places].sort().reverse());
console.log("String Orignal Order",places);
places.reverse();
console.log("reverse ",places);
places.reverse();
console.log("again Reverse",places);
console.log("Orignal Order");
console.log(places);
places.sort();
console.log(places);
places.reverse();
console.log(places);
//Question 18
var guest:string[]=["Eren","Naruto","Luffy"];
console.log("No of guests Are",guest.length);
//Question19
// Create an array of famous cities
const famousCities: string[] = [
  "New York City, USA",
  "Paris, Pakistan",
  "Tokyo, Japan",
];

// Print the list of famous cities
console.log("List of Famous Cities:");
for (var i=0;i<1;i++) {
  console.log(famousCities);
}
console.log("List of Famous Cities:");
for (const city of famousCities) {
    console.log(city);}
//Question 20
type cities={
name:string;
famous:string;
}
var cities:cities={
  name:"faisalabad",
  famous :"textile"
}
console.log(cities.name);
//Question21
const numbers: number[] = [1, 2, 3, 4, 5];
// Intentional index error - accessing an element at an out-of-bounds index
const element = numbers[10];
// This line will cause an error so i am commenting it
//console.log(element); 
//question22
let age = 25;

// Test 1: Is the age less than 18?
console.log("Test 1: Is age < 18? I predict False.");
console.log(age < 18); // This will print False

// Test 2: Is the age greater than or equal to 18?
console.log("\nTest 2: Is age >= 18? I predict True.");
console.log(age >= 18); // This will print True

// Test 3: Is the age equal to 25?
console.log("\nTest 3: Is age == 25? I predict True.");
console.log(age == 25); // This will print True

// Test 4: Is the age not equal to 30?
console.log("\nTest 4: Is age != 30? I predict True.");
console.log(age != 30); // This will print True

// Test 5: Is the age between 20 and 30 (inclusive)?
console.log("\nTest 5: Is 20 <= age <= 30? I predict True.");
console.log(age >= 20 && age <= 30); // This will print True

// Test 6: Is the age divisible by 5?
console.log("\nTest 6: Is age divisible by 5? I predict True.");
console.log(age % 5 === 0); // This will print True

// Test 7: Is the age a negative number?
console.log("\nTest 7: Is age < 0? I predict False.");
console.log(age < 0); // This will print False

// Test 8: Is the age an even number?
console.log("\nTest 8: Is age even? I predict False.");
console.log(age % 2 === 0);

//Question23
// Tests for equality and inequality with strings
var fruit1 = "apple";
var fruit2 = "banana";

console.log("Equality Test 1: Are the fruits equal? I predict False.");
console.log(fruit1 === fruit2); // This will print False

console.log("\nInequality Test 1: Are the fruits not equal? I predict True.");
console.log(fruit1 !== fruit2); // This will print True

// Tests using the lowercase function
const text1 = "Hello, World!";
const text2 = "hello, world!";

console.log("\nLowercase Test 1: Are the texts lowercase equal? I predict True.");
console.log(text1.toLowerCase() === text2.toLowerCase()); // This will print True

// Numerical tests
var number1 = 42;
var number2 = 30;

console.log("\nEquality Test 2: Are the numbers equal? I predict False.");
console.log(number1 === number2); // This will print False

console.log("\nInequality Test 2: Are the numbers not equal? I predict True.");
console.log(number1 !== number2); // This will print True

console.log("\nGreater Than Test: Is number1 > number2? I predict True.");
console.log(number1 > number2); // This will print True

console.log("\nLess Than Test: Is number1 < number2? I predict False.");
console.log(number1 < number2); // This will print False

console.log("\nGreater Than or Equal To Test: Is number1 >= number2? I predict True.");
console.log(number1 >= number2); // This will print True

console.log("\nLess Than or Equal To Test: Is number1 <= number2? I predict False.");
console.log(number1 <= number2); // This will print False

// Tests using "and" and "or" operators
const isSunny = true;
const isWeekend = false;

console.log("\nAnd Operator Test: Is it sunny AND a weekend? I predict False.");
console.log(isSunny && isWeekend); // This will print False

console.log("\nOr Operator Test: Is it sunny OR a weekend? I predict True.");
console.log(isSunny || isWeekend); // This will print True

// Test whether an item is in an array
const fruitsArray = ["apple", "banana", "cherry", "date"];

console.log("\nArray Inclusion Test: Is 'cherry' in the fruits array? I predict True.");
console.log(fruitsArray.includes("cherry")); // This will print True

// Test whether an item is not in an array
console.log("\nArray Exclusion Test: Is 'grape' not in the fruits array? I predict True.");
console.log(!fruitsArray.includes("grape")); // This will print True
//Question 24

// Equality test with strings (True)
const string1: string = "hello";
const string2: string = "hello";
const result1: boolean = string1 === string2;

// Inequality test with strings (False)
const string3: string = "hello";
const string4: string = "world";
const result2: boolean = string3 !== string4;
// Numerical equality test (True)
const num1: number = 10;
const num2: number = 10;
const result4: boolean = num1 === num2;

// Numerical inequality test (False)
const num3: number = 5;
const num4: number = 10;
const result5: boolean = num3 !== num4;

// Greater than test (True)
const num5: number = 15;
const num6: number = 10;
const result6: boolean = num5 > num6;

// Less than test (True)
const num7: number = 5;
const num8: number = 10;
const result7: boolean = num7 < num8;

// Greater than or equal to test (True)
const num9: number = 10;
const num10: number = 10;
const result8: boolean = num9 >= num10;

// Less than or equal to test (True)
const num11: number = 5;
const num12: number = 10;
const result9: boolean = num11 <= num12;
// "And" operator test (True)
const condition1: boolean = true;
const condition2: boolean = true;
const result10: boolean = condition1 && condition2;

// "Or" operator test (True)
const condition3: boolean = true;
const condition4: boolean = false;
const result11: boolean = condition3 || condition4;
// Item in array test (True)
const array: number[] = [1, 2, 3, 4, 5];
const itemToFind: number = 3;
const result12: boolean = array.includes(itemToFind);
// Item not in array test (False)
const array2: number[] = [1, 2, 3, 4, 5];
const itemToFind2: number = 6;
const result13: boolean = !array2.includes(itemToFind2);
//-----------------------------------Question No 24------------------------------------------------------
var alien_color_pass: string = 'green';

if (alien_color_pass === 'green') {
    console.log("Player just earned 5 points.");
}

// Failing version
var alien_color_fail: string = 'red';

if (alien_color_fail === 'green') {
    console.log("Player just earned 5 points.");
}

//-----------------------------------Question No 25------------------------------------------------------
var alien_Color_V1 = 'green';

if (alien_Color_V1 === 'green') {
  console.log("Congratulations! You just earned 5 points for shooting the green alien.");
} else {
  console.log("Congratulations! You just earned 10 points for shooting an alien that isn't green.");
}
//Version 2 (Runs the else block - Alien color isn't green)
var alien_Color_V2 = 'red';

if (alien_Color_V2 === 'green') {
  console.log("Congratulations! You just earned 5 points for shooting the green alien.");
} else {
  console.log("Congratulations! You just earned 10 points for shooting an alien that isn't green.");
}

//-----------------------------------Question No 26------------------------------------------------------

var alien_Color_Green = 'green';

if (alien_Color_Green === 'green') {
  console.log("Congratulations! You just earned 5 points for shooting the green alien.");
} else if (alien_Color_Green === 'yellow') {
  console.log("Congratulations! You just earned 10 points for shooting the yellow alien.");
} else if (alien_Color_Green === 'red') {
  console.log("Congratulations! You just earned 15 points for shooting the red alien.");
}
//Version 2 (Yellow Alien - 10 points)
var alien_Color_Yellow = 'yellow';

if (alien_Color_Yellow === 'green') {
  console.log("Congratulations! You just earned 5 points for shooting the green alien.");
} else if (alien_Color_Yellow === 'yellow') {
  console.log("Congratulations! You just earned 10 points for shooting the yellow alien.");
} else if (alien_Color_Yellow === 'red') {
  console.log("Congratulations! You just earned 15 points for shooting the red alien.");
}
//Version 3 (Red Alien - 15 points)
var  alien_Color_Red= 'red';

if (alien_Color_Red === 'green') {
  console.log("Congratulations! You just earned 5 points for shooting the green alien.");
} else if (alien_Color_Red === 'yellow') {
  console.log("Congratulations! You just earned 10 points for shooting the yellow alien.");
} else if (alien_Color_Red === 'red') {
  console.log("Congratulations! You just earned 15 points for shooting the red alien.");
}

//-----------------------------------Question No 27------------------------------------------------------

var Age = 35; 

if (Age < 2) {
  console.log("The person is a baby.");
} else if (Age >= 2 && Age < 4) {
  console.log("The person is a toddler.");
} else if (Age >= 4 && Age < 13) {
  console.log("The person is a kid.");
} else if (Age >= 13 && Age < 20) {
  console.log("The person is a teenager.");
} else if (Age >= 20 && Age < 65) {
  console.log("The person is an adult.");
} else {
  console.log("The person is an elder.");
}

//-----------------------------------Question No 28------------------------------------------------------
var favorite_fruits = ['apple', 'banana', 'strawberry'];

if (favorite_fruits.includes('apple')) {
  console.log("You really like apples!");
}

if (favorite_fruits.includes('banana')) {
  console.log("You really like bananas!");
}

if (favorite_fruits.includes('strawberry')) {
  console.log("You really like strawberries!");
}

if (favorite_fruits.includes('orange')) {
  console.log("You really like oranges!");
}

if (favorite_fruits.includes('kiwi')) {
  console.log("You really like kiwis!");
}

//-----------------------------------Question No 29------------------------------------------------------


var userNames: string[] = ['admin', 'Ali', 'Fasih', 'Huzaifa', 'Bilal'];

for (var username of userNames) {
  if (username === 'admin') {
    console.log("Hello admin, would you like to see a status report?");
  } else {
    console.log(`Hello ${username}, thank you for logging in again.`);
  }
}


//-----------------------------------Question No 30------------------------------------------------------
let usernames: string[] = ['admin', 'Ali', 'Fasih', 'Huzaifa', 'Bilal'];

if (usernames.length === 0) {
  console.log("We need to find some users!");
} else {
  for (var username of usernames) {
    if (username === 'admin') {
      console.log("Hello admin, would you like to see a status report?");
    } else {
      console.log(`Hello ${username}, thank you for logging in again.`);
    }
  }
}

// Remove all usernames to test the "empty list" condition
usernames = [];

if (usernames.length === 0) {
  console.log("We need to find some users!");
}

//---Question No 31---
//--Checking Usernames: Do the following to create a program that simulates how websites ensure that everyone has a unique username.
const current_users: string[] = ['admin', 'Ali', 'Fasih', 'Huzaifa', 'Bilal'];

// List of new users
const new_users: string[] = ['Ali', 'Fasih', 'Sara', 'Haroon', 'Aaniq'];

// Function to check if a username is already used 
function isUsernameTaken(username: string): boolean {
  return current_users.some((user) => user.toLowerCase() === username.toLowerCase());
}

// Loop ss
for (const newUsername of new_users) {
  if (isUsernameTaken(newUsername)) {
    console.log(`Sorry, the username '${newUsername}' is already taken. Please choose a different one.`);
  } else {
    console.log(`Congratulations, the username '${newUsername}' is available.`);
  }
}

//-----------------------------------Question No 32------------------------------------------------------
//--Ordinal Numbers: Ordinal numbers indicate their position in a array, such as 1st or 2nd. Most ordinal numbers end in th, except 1, 2, and 3.
//• Store the numbers 1 through 9 in a array.

//• Loop through the array.

//• Use an if-else chain inside the loop to print the proper ordinal ending for each number. Your output should read "1st 2nd 3rd 4th 5th 6th 7th 8th 9th", and each result should be on a separate line.
var numbe: number[] = [1, 2, 3, 4, 5, 6, 7, 8, 9];

for (var number of numbe) {
  let ordinal: string;

  if (number === 1) {
    ordinal = '1st';
  } else if (number === 2) {
    ordinal = '2nd';
  } else if (number === 3) {
    ordinal = '3rd';
  } else if (number >= 4 && number <= 20) {
    ordinal = `${number}th`;
  } else {
    // Handle numbers greater than 20
    var lastDigit = number % 10;
    switch (lastDigit) {
      case 1:
        ordinal = `${number}st`;
        break;
      case 2:
        ordinal = `${number}nd`;
        break;
      case 3:
        ordinal = `${number}rd`;
        break;
      default:
        ordinal = `${number}th`;
        break;
    }
  }

  console.log(ordinal);
}

//-----------------------------------Question No 33------------------------------------------------------
//--Pizzas: Think of at least three kinds of your favorite pizza. Store these pizza names in a array, and then use a for loop to print the name of each pizza.
//• Modify your for loop to print a sentence using the name of the pizza instead of printing just the name of the pizza. For each pizza you should have one line of output containing a simple statement like I like pepperoni pizza.

//• Add a line at the end of your program, outside the for loop, that states how much you like pizza. The output should consist of three or more lines about the kinds of pizza you like and then an additional sentence, such as I really love pizza!
// Array of favorite pizza names
var favoritePizzas: string[] = ['Pepperoni', 'Margherita', 'BBQ Chicken'];

// Print the names of each pizza
console.log('My favorite pizzas:');
for (var pizza of favoritePizzas) {
    console.log(pizza);
}

// Print a sentence about each pizza
console.log('\nDescription of my favorite pizzas:');
for (var pizza of favoritePizzas) {
    console.log(`I like ${pizza} pizza.`);
}

// Add a line about how much you like pizza
console.log('\nI really love pizza!');


//-----------------------------------Question No 34------------------------------------------------------
//--Animals: Think of at least three different animals that have a common characteristic. Store the names of these animals in a list, and then use a for loop to print out the name of each animal. • Modify your program to print a statement about each animal, such as A dog would make a great pet. • Add a line at the end of your program stating what these animals have in common. You could print a sentence such as Any of these animals would make a great pet!
var animals: string[] = ['Dog', 'Cat', 'Rabbit'];

for (var animal of animals) {
  console.log(`A ${animal} would make a great pet.`);
}

console.log("Any of these animals would make a great pet!");

//-----------------------------------Question No 35------------------------------------------------------
//--T-Shirt: Write a function called make_shirt() that accepts a size and the text of a message that should be printed on the shirt. The function should print a sentence summarizing the size of the shirt and the message printed on it. Call the function.
// Define the make_shirt function
function makeShirt(size: string, message: string): void {
  console.log(`A ${size}-sized shirt will be printed with the message: "${message}"`);
}

// Call the function with different arguments
makeShirt('Medium', 'Hello World!');
makeShirt('Large', 'I Love TypeScript!');


//-----------------------------------Question No 36------------------------------------------------------
//--Large Shirts: Modify the make_shirt() function so that shirts are large by default with a message that reads I love TypeScript. Make a large shirt and a medium shirt with the default message, and a shirt of any size with a different message.

// Define the make_shirt function with default values
function make_shirt(size: string = 'Large', message: string = 'I love TypeScript'): void {
  console.log(`A ${size}-sized shirt will be printed with the message: "${message}"`);
}

// Create shirts with default and custom messages
make_shirt(); // Large shirt with default message
make_shirt('Medium'); // Medium shirt with default message
make_shirt('Small', 'Custom message for a Small shirt'); // Small shirt with a custom message


//-----------------------------------Question No 37------------------------------------------------------
//--Cities: Write a function called describe_city() that accepts the name of a city and its country. The function should print a simple sentence, such as Karachi is in Pakistan. Give the parameter for the country a default value. Call your function for three different cities, at least one of which is not in the default country.
// Define the describe_city function with a default country value
function describe_city(city: string, country: string = 'Unknown'): void {
  console.log(`${city} is in ${country}.`);
}

// Call the function for three different cities
describe_city('Karachi', 'Pakistan'); // Karachi is in Pakistan
describe_city('Paris', 'France'); // Paris is in France
describe_city('Sydney'); // Sydney is in Unknown (default)

//-----------------------------------Question No 38------------------------------------------------------
//--City Names: Write a function called city_country() that takes in the name of a city and its country. The function should return a string formatted like this:

//"Lahore, Pakistan"

//Call your function with at least three city-country pairs, and print the value that’s returned.
function city_country(city: string, country: string): string {
  return `${city}, ${country}`;
}

// Calling the function with city-country pairs
const city1 = city_country('Lahore', 'Pakistan');
const city2 = city_country('New York', 'USA');
const city3 = city_country('Paris', 'France');

// Printing the formatted strings
console.log(city1); // This will print: Lahore, Pakistan
console.log(city2); // This will print: New York, USA
console.log(city3); // This will print: Paris, France


//-----------------------------------Question No 39------------------------------------------------------
//--Album: Write a function called make_album() that builds a Object describing a music album. The function should take in an artist name and an album title, and it should return a Object containing these two pieces of information. Use the function to make three dictionaries representing different albums. Print each return value to show that Objects are storing the album information correctly. Add an optional parameter to make_album() that allows you to store the number of tracks on an album. If the calling line includes a value for the number of tracks, add that value to the album’s Object. Make at least one new function call that includes the number of tracks on an album.
function make_album(artist: string, title: string, tracks?: number): { artist: string; title: string; tracks?: number } {
  const album: { artist: string; title: string; tracks?: number } = {
      artist: artist,
      title: title,
  };

  if (tracks !== undefined) {
      album.tracks = tracks;
  }

  return album;
}

// Creating album objects using the make_album function
const album1 = make_album('Artist1', 'Album1');
const album2 = make_album('Artist2', 'Album2', 12); // Example with a specified number of tracks
const album3 = make_album('Artist3', 'Album3');

// Printing album information
console.log(album1); // Object { artist: 'Artist1', title: 'Album1' }
console.log(album2); // Object { artist: 'Artist2', title: 'Album2', tracks: 12 }
console.log(album3); // Object { artist: 'Artist3', title: 'Album3' }

//-----------------------------------Question No 40------------------------------------------------------
//--Magicians: Make a array of magician’s names. Pass the array to a function called show_magicians(), which prints the name of each magician in the array.
function showMagicians(magicians: string[]): void {
  for (const magician of magicians) {
      console.log(magician);
  }
}

// Array of magician names
var magician_Names: string[] = ['David Copperfield', 'Houdini', 'Penn & Teller', 'Dynamo'];

// Calling the show_magicians function to print the magician names
showMagicians(magician_Names);

//-----------------------------------Question No 41------------------------------------------------------
//--Great Magicians: Start with a copy of your program from Exercise 39. Write a function called make_great() that modifies the array of magicians by adding the phrase the Great to each magician’s name. Call show_magicians() to see that the list has actually been modified.
function makeGreat(magicians: string[]): string[] {
  const greatMagicians: string[] = [];
  for (var magician of magicians) {
      greatMagicians.push(`${magician} the Great`);
  }
  return greatMagicians;
}

function show_my_magicians(magicians: string[]): void {
  for (var magician of magicians) {
      console.log(magician);
  }
}

// Array of magician names
var magician_Names: string[] = ['David Copperfield', 'Houdini', 'Penn & Teller', 'Dynamo'];

// Adding "the Great" to magician names
var great_Magicians = make_great(magician_Names);

// Calling the show_magicians function to print the updated magician names
show_magicians(great_Magicians);

//-----------------------------------Question No 42------------------------------------------------------
//--Unchanged Magicians: Start with your work from Exercise 40. Call the function make_great() with a copy of the array of magicians’ names. Because the original array will be unchanged, return the new array and store it in a separate array. Call show_magicians() with each array to show that you have one array of the original names and one array with the Great added to each magician’s name.

function make_great(magicians: string[]): string[] {
  const greatMagicians: string[] = [];
  for (var magician of magicians) {
      greatMagicians.push(`${magician} the Great`);
  }
  return greatMagicians;
}

function show_magicians(magicians: string[]): void {
  for (var magician of magicians) {
      console.log(magician);
  }
}

// Array of magician names
var magicianNames: string[] = ['David Copperfield', 'Houdini', 'Penn & Teller', 'Dynamo'];

// Create a copy of the magicianNames array
var originalMagicians = [...magicianNames];

// Adding "the Great" to magician names without modifying the original array
var greatMagicians = make_great(originalMagicians);

// Calling show_magicians with the original and modified arrays
console.log('Original Magicians:');
show_magicians(originalMagicians);

console.log('\nGreat Magicians:');
show_magicians(greatMagicians);


//-----------------------------------Question No 43------------------------------------------------------
//--Sandwiches: Write a function that accepts a array of items a person wants on a sandwich. The function should have one parameter that collects as many items as the function call provides, and it should print a summary of the sandwich that is being ordered. Call the function three times, using a different number of arguments each time.
function orderSandwich(...items: string[]): void {
  if (items.length === 0) {
      console.log('You ordered an empty sandwich. Please select some items.');
  } else {
      console.log('Sandwich Summary:');
      for (const item of items) {
          console.log(`- ${item}`);
      }
      console.log('Enjoy your sandwich!\n');
  }
}

// Call the function 
orderSandwich('Turkey', 'Lettuce', 'Tomato', 'Mayo');
orderSandwich('Ham', 'Swiss Cheese', 'Mustard');
orderSandwich();

//-----------------------------------Question No 44------------------------------------------------------
//--Cars: Write a function that stores information about a car in a Object. The function should always receive a manufacturer and a model name. It should then accept an arbitrary number of keyword arguments. Call the function with the required information and two other name-value pairs, such as a color or an optional feature. Print the Object that’s returned to make sure all the information was stored correctly.
function storeCarInfo(manufacturer: string, model: string, ...options: [string, any][]): Record<string, any> {
  const car: Record<string, any> = {
      manufacturer,
      model,
  };

  for (const [key, value] of options) {
      car[key] = value;
  }

  return car;
}

// Call the function with required and optional information
const carInfo = storeCarInfo('Toyota', 'Camry', ['color', 'Blue'], ['features', ['GPS', 'Sunroof']]);

// Print the car object
console.log(carInfo);

